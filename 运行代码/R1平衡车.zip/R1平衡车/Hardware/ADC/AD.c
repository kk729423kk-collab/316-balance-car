#include "stm32f10x.h"                  // Device header

void AD_Init(void)
{
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_ADC1, ENABLE);	
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE);
	
	RCC_ADCCLKConfig(RCC_PCLK2_Div8);	
	
	GPIO_InitTypeDef GPIO_InitStructure;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AIN;
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_1;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOB, &GPIO_InitStructure);	
	ADC_RegularChannelConfig(ADC1, ADC_Channel_9, 1, ADC_SampleTime_239Cycles5);		
	
	ADC_InitTypeDef ADC_InitStructure;						
	ADC_InitStructure.ADC_Mode = ADC_Mode_Independent;	
	ADC_InitStructure.ADC_DataAlign = ADC_DataAlign_Right;	
	ADC_InitStructure.ADC_ExternalTrigConv = ADC_ExternalTrigConv_None;	
	ADC_InitStructure.ADC_ContinuousConvMode = DISABLE;		
	ADC_InitStructure.ADC_ScanConvMode = DISABLE;			
	ADC_InitStructure.ADC_NbrOfChannel = 1;					
	ADC_Init(ADC1, &ADC_InitStructure);						
	
	
	ADC_Cmd(ADC1, ENABLE);									
	

	ADC_ResetCalibration(ADC1);							
	while (ADC_GetResetCalibrationStatus(ADC1) == SET);
	ADC_StartCalibration(ADC1);
	while (ADC_GetCalibrationStatus(ADC1) == SET);
}

uint16_t AD_GetValue(void)
{
	ADC_SoftwareStartConvCmd(ADC1, ENABLE);					
	while (ADC_GetFlagStatus(ADC1, ADC_FLAG_EOC) == RESET);	
	return ADC_GetConversionValue(ADC1);					
}

uint16_t  Battery_GetValue(void)
{
	uint8_t Persentage=0;
	uint16_t vol=0,sum;
	uint8_t i;
	for(i=0;i<10;i++)
	{
		sum+=(AD_GetValue()/4095.0*3.3)*100;
	}
	vol=sum/10+0.5;
	if(vol>280)Persentage=100;
	else if(vol<180)Persentage=0;
	else	Persentage=vol-180;
	return Persentage;
}
