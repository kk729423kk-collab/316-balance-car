#include "stm32f10x.h"                  // Device header
#include "PWM.h"
void motor_init(uint32_t psr,uint32_t arr)
{
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);		//����GPIOA��ʱ��
//	//��GPIO��ʱ�ӣ��ȴ򿪸��ò����޸��Ƿ�ͣ�ø��ù���
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB | RCC_APB2Periph_AFIO,ENABLE);
//	//�ر�JTAG��ʹ��SWD
	GPIO_PinRemapConfig(GPIO_Remap_SWJ_JTAGDisable,ENABLE);
	
	GPIO_InitTypeDef GPIO_InitStructure;
	
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_4 | GPIO_Pin_5;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	
	GPIO_Init(GPIOB, &GPIO_InitStructure);						//��PA4��PA5���ų�ʼ��Ϊ�������	
	
	GPIO_Init(GPIOA,&GPIO_InitStructure);
	
	PWM_Init(psr,arr)	;	
}
void motor_Right_set(int speed)
{
	if(speed>=0)
	{
		GPIO_SetBits(GPIOA,GPIO_Pin_4);
		GPIO_ResetBits(GPIOA,GPIO_Pin_5);
		TIM_SetCompare3(TIM1,speed);
	}
	else
	{
		GPIO_SetBits(GPIOA,GPIO_Pin_5);
		GPIO_ResetBits(GPIOA,GPIO_Pin_4);
		TIM_SetCompare3(TIM1,-speed);
	}
}
void motor_Left_set(int speed)
{
	if(speed>=0)
	{
		GPIO_SetBits(GPIOB,GPIO_Pin_5);
		GPIO_ResetBits(GPIOB,GPIO_Pin_4);
		TIM_SetCompare4(TIM1,speed);
	}
	else
	{
		GPIO_SetBits(GPIOB,GPIO_Pin_4);
		GPIO_ResetBits(GPIOB,GPIO_Pin_5);
		TIM_SetCompare4(TIM1,-speed);
	}
}



	